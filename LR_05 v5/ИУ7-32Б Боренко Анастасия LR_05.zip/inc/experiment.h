#ifndef OUTPUT_ANSWER_H
#define OUTPUT_ANSWER_H

#include "../inc/help_functions.h"
#include "../inc/list_model.h"
#include "../inc/array_model.h"

void array_experiment();
void list_experiment();

void time_list_experiment(int condition);

#endif
