#ifndef TESTING_H
#define TESTING_H

#include "experiment.h"

void testing();

#endif