#ifndef INPUT_H
#define INPUT_H

#include "stack_work.h"

int input_array_stack(array_stack_t *stack);
int input_list_stack(list_stack_node_t **head);
void clearInputBuf(void);

#endif