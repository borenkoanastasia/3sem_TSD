#ifndef CHOISES_H
#define CHOISES_H

#include "sort.h"
#include "input.h"

void choise_list_stacks_sort(adress_stack_node_t **h);
void choise_array_stacks_sort(adress_stack_node_t **h);
void choise_output_adress_stack(adress_stack_node_t **h);

#endif