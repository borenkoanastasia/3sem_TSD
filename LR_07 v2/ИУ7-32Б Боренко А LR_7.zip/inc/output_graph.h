#ifndef OUTPUT_GRAPH_H
#define OUTPUT_GRAPH_H

#include "common.h"

void output_graph_as_dot(graph_t g, char *filename);

#endif