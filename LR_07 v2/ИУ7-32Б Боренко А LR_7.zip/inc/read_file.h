#ifndef READ_FILE_H
#define READ_FILE_H

#include "types_work.h"

int read_file(char *filename, graph_t **g);

#endif