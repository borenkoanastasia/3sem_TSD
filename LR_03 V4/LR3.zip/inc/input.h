#ifndef INPUT_H
#define INPUT_H

#include "common.h"
#include "memory_work.h"
#include "matrix.h"

int input_vec_and_matrix(norm_matrix_t *vec, norm_matrix_t *m);

#endif