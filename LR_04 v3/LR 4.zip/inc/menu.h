#ifndef MENU_H
#define MENU_H

#include "common.h"
#include "help.h"
#include "sort.h"
#include "stack_work.h"
#include "testing.h"

void menu();

#endif