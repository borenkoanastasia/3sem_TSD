#ifndef STACK_WORK_H
#define STACK_WORK_H

#include "common.h"
#include "help.h"
#include "adress_work.h"
#include "input.h"

int spec_list_pop(list_stack_node_t **head, adress_stack_node_t **h);
//void spec_list_free(list_stack_node_t **head, adress_stack_node_t **h);

//void list_stack_work();

//int spec_array_pop(array_stack_t *stack, adress_stack_node_t **h);
//void spec_array_free(array_stack_t *stack, adress_stack_node_t **h);

//void array_stack_work();

void choise_stack_work();

#endif