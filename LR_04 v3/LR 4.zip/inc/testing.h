#ifndef TESTING_H
#define TESTING_H

#include "sort.h"
#include "common.h"

void testing();

#endif