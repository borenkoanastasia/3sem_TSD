#include "../inc/menu.h"

int main()
{
	printf("%ld\n", sizeof(int *));
	//testing();
	menu();
	return OK;
}
