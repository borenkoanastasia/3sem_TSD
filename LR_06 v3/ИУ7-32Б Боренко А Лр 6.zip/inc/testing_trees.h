#ifndef TESTING_TREES_H
#define TESTING_TREES_H

#include "tree_work.h"
#include "balance_work.h"
#include "hash_work.h"

void testing_trees_time(char *test_filename);
void testing_all(int i, char *test_filename);

#endif