#ifndef MENU_H
#define MENU_H

#include "tree_work.h"
#include "balance_work.h"
#include "hash_work.h"

void main_menu();

#endif